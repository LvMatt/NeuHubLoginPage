﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace XMLParser
{
    class Program
    {
        static void Main(string[] args)
        {
            int totalC = 0;

            XmlDocument xmlDoc = new XmlDocument();
            string XmlPath = Directory.GetCurrentDirectory() + @"\MainXMLFile.xml";
            xmlDoc.Load(XmlPath);

            XmlNodeList CListImplementation = xmlDoc.GetElementsByTagName("implementation");

            totalC = CListImplementation.Count;

            for (int i = 0; i < CListImplementation.Count; i++)
            {
                Console.WriteLine("Situation: ");
                Console.WriteLine(CListImplementation[i].InnerText.ToString());
            }

            Console.ReadLine();

            
        }
    }
}
